export DEBUG_VITERBI=yes
Trigram testing default.config t.txt