// ==========  This file is under  LGPL, the GNU Lesser General Public Licence
// ==========  Dialing Graphematical Module (www.aot.ru)
// ==========  Copyright by Alexey Sokirko (1996-2001)
#pragma warning (disable  : 4530)
#pragma warning (disable  : 4786)

#include "StdGraph.h"

