// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#ifndef EngStdSynan_h
#define EngStdSynan_h


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include  "../common/utilit.h"
#include "../SynCommonLib/Sentence.h"

// TODO: reference additional headers your program requires here

#endif
