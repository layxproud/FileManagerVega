//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Checker.rc
//
#define IDS_OPNERR                      3
#define ID_DELETE_BASE                  3
#define IDS_URDERR                      4
#define IDS_NOBASE                      5
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHECKER_DIALOG              102
#define IDS_PROMPT_DELETE_BASE          102
#define IDR_MAINFRAME                   128
#define IDD_PROCEED_DIALOG              129
#define IDD_PROGRESS                    160
#define IDC_EDIT1                       1000
#define IDC_B1                          1001
#define IDC_TEXT2                       1001
#define IDC_EDIT2                       1002
#define IDC_TEXT3                       1002
#define IDC_B2                          1003
#define IDC_EDIT3                       1004
#define IDC_B3                          1005
#define IDC_RADIO1                      1006
#define IDC_RADIO2                      1007
#define IDC_EDIT4                       1008
#define IDC_FROM                        1008
#define IDC_SENTNO                      1009
#define IDC_NUMB                        1009
#define IDC_BASENO                      1010
#define IDC_PREV                        1011
#define IDC_NEXT                        1012
#define IDC_ADD                         1013
#define IDC_SKIP                        1014
#define IDC_ADD2                        1015
#define IDC_TEXT1                       1016
#define IDC_COMMENTS                    1018
#define IDC_COMBO1                      1019
#define IDC_STATIC4                     1020
#define IDC_STATIC3                     1021
#define IDC_STATIC6                     1022
#define IDC_BUTTON1                     1023
#define IDC_ADD_ALL                     1023
#define IDC_TPB_PB                      1060
#define IDC_TPB_ST                      1061

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
