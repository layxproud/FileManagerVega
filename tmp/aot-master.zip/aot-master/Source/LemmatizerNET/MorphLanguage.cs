﻿namespace LemmatizerNET {
	public enum MorphLanguage {
		Russian = 1,
		English = 2,
		German = 3
}
}
