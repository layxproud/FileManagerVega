﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("LemmatizerNET")]
[assembly: AssemblyDescription("Morphology for .NET (www.aot.ru)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("LemmatizerNET")]
[assembly: AssemblyCopyright("Library GPL (LGPL)")]
[assembly: AssemblyTrademark("AOT")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d51df5e8-e681-4342-a728-da7df9878569")]
[assembly: AssemblyVersion("0.1.*")]

