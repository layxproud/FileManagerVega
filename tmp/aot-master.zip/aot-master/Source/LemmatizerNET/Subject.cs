﻿
namespace LemmatizerNET {
	public enum Subject {
		Finance = 1,
		Computer = 2,
		Literature = 3
	}
}
