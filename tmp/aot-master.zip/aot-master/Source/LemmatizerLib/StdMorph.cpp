#pragma warning(disable:4786)
#pragma warning(disable:4530)


#include "StdMorph.h"
