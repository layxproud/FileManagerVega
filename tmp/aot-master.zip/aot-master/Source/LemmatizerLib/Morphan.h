#include "../common/utilit.h"
class CMorphologyHolder;
extern std::string LemmatizeJson(std::string WordForm, const CMorphologyHolder* Holder, bool withParadigms, bool prettyJson=false, bool sortForms=false);
