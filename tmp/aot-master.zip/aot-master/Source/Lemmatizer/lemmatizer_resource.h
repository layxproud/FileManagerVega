//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Lemmatizer.rc
//
#define IDS_PROJNAME                    100
#define IDR_LEMMATIZERRUS               101
#define IDR_GENERATOR                   102
#define IDR_PARADIGM                    105
#define IDR_PARADIGMCOLLECTION          106
#define IDR_COMGENERATOR                109
#define IDR_COMPARADIGM                 116
#define IDR_COMPARADIGMCOLLECTION       118
#define IDR_COMLEMMATIZERRUSSIAN        119
#define IDR_COMLEMMATIZERENGLISH        120
#define IDR_COMPLMLINECOLLECTION        124
#define IDR_COMPARADIGMITERATOR         127
#define IDR_MORPHBINGENERATOR           129
#define IDR_COMLEMMATIZERGERMAN         130

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           131
#endif
#endif
