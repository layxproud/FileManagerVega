#pragma once

//----------------------------------------------------------------------------
// abstract class
//----------------------------------------------------------------------------
class CMWDocument: public CDocument
{
protected:
	CMWDocument()	{}
public:	
//	virtual	MorphoWizard*	GetWizard()=0;
};
