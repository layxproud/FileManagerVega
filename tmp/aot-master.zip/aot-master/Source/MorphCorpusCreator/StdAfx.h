// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__E92AD038_A92C_40A9_A5A4_76C2061F10CC__INCLUDED_)
#define AFX_STDAFX_H__E92AD038_A92C_40A9_A5A4_76C2061F10CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <stdio.h>

#pragma warning(disable:4786)
#pragma warning(disable:4503)


#include "../common/util_classes.h"
#include <iostream>
#include <algorithm>
#include <fstream>
#include <string>
#include <vector>
#include <set>
#include <map>

#include "..\common\ComSyntaxHolder.h"


// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__E92AD038_A92C_40A9_A5A4_76C2061F10CC__INCLUDED_)
