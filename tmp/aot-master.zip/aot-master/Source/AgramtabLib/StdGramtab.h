#ifndef stdgramtab_h
#define stdgramtab_h


#include "../common/utilit.h"
#include "rus_consts.h"
#include "ger_consts.h"
#include "eng_consts.h"
#include "agramtab_.h"


#endif
