#pragma warning(disable:4786)
#include "GerSynan.h"
#include "GerSentence.h"










