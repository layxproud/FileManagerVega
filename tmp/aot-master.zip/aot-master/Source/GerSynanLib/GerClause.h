// ==========  This file is under  LGPL, the GNU Lesser General Public Licence
// ==========  Dialing Syntax Analysis (www.aot.ru)
// ==========  Copyright by Dmitry Pankratov, Igor Nozhov, Alexey Sokirko

#ifndef rus_clause_h
#define rus_clause_h

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "../SynCommonLib/Clause.h"
#include "GerSynan.h"
#include "GerWord.h"
#include "GerGroup.h"



#pragma warning(disable:4786) 




#endif 
