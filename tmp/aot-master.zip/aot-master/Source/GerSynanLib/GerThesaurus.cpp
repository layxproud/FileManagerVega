
#include "GerSynan.h"
#include "GerThesaurus.h"
#include "../SynCommonLib/SynPlmLine.h"


CGerThesaurusForSyntax::CGerThesaurusForSyntax(const CSyntaxOpt* Opt): CThesaurusForSyntax(Opt)
{
};
void CGerThesaurusForSyntax::AssignMainGroupsToModel(CGroups& model, const CInnerModel& piModel)
{
	return;
}
