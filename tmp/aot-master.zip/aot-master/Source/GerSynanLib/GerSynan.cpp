#pragma warning (disable : 4786)


#include "GerSynan.h"
